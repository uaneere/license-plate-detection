# License Plate Detection System

**Student:** Ruslan Agafonov & Angelina Chernikova
**Group:** 972401

## Description

License plate detection system using YOLO

## Project Structure

```
license-plate-detection/
├── src/
│   ├── __init__.py
│   ├── logger.py          # Logging (singleton)
│   ├── model_impl.py      # My_LicensePlate_Model class
│   ├── video_mode.py      # Video file processing
│   ├── evaluate.py        # Model evaluation
│   ├── track_smoothing.py # Anti-aliasing
│   ├── visualization.py   # Rendering
│   └── train.py           # Model training
├── scripts/
│   └── split_dataset.py   # Dataset splitting
├── main.py                # CLI entry point
├── pyproject.toml         # Poetry config
├── dist/
│   └── *.whl              # Built package
├── Dockerfile
├── docker-compose.yaml
├── .dockerignore
├── .gitignore
└── README.md
```

## Installation with Poetry

### Prerequisites

```bash
pip install poetry
```

### Install dependencies

```bash
git clone https://github.com/uaneere/license-plate-detection.git
cd license-plate-detection

poetry install

poetry run pip install ultralytics
poetry run pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
poetry run python -c "import torch; print(torch.cuda.is_available())"

poetry env activate
```

## Building .whl Package

```bash
poetry build
```

### What's inside .whl?

```
src/__init__.py
src/logger.py
src/model_impl.py
src/video_mode.py
src/camera_mode.py
src/evaluate.py
src/train.py
main.py
```

- ❌ No model weights (.pt)
- ❌ No dataset (data/)
- ❌ No venv
- ❌ No runs/

## Dataset Preparation

### Option 1: Use ready dataset

```bash
# Download from Roboflow
# Place images and labels in data/train/ and data/valid/
# Create data/data.yaml
```

### Option 2: Create your own dataset

```bash
# Markup video with Roboflow, Label Studio, or CVAT
# Export in YOLO format
# Split dataset
python scripts/split_dataset.py
```

### data.yaml structure

```yaml
train: train/images
val: valid/images
test: test/images

nc: 1
names: ['License-Plate']
```

## Training

```bash

```

### Training results

| Metric     | Value  |
|------------|--------|
| mAP50      | 0.669  |
| mAP50-95   | 0.373  |
| Precision  | 0.825  |
| Recall     | 0.597  |

## Usage

### Video processing

```bash

```

### Model evaluation

```bash

```

### Model info

```bash
poetry run python main.py info \
  -m runs/detect/train/weights/best.pt
```

## Docker

### Build image

```bash
docker build -t lpd .
```

### Run video processing

```bash
# Prepare directories
mkdir -p test_videos output
cp test.mp4 test_videos/

# Run container
docker run --rm \
  -v $(pwd)/runs:/app/runs \
  -v $(pwd)/output:/app/output \
  -v $(pwd)/test_videos:/app/test_videos \
  lpr-detector \
  video \
  -i /app/test_videos/test.mp4 \
  -o /app/output/result.mp4 \
  -m /app/runs/detect/train/weights/best.pt
```

### Using docker-compose

```yaml
services:
  lpr:
    build: .
    container_name: license-plate-detection
    volumes:
      - ./runs:/app/runs
      - ./output:/app/output
      - ./test_videos:/app/test_videos
    command: >
      video
      -i /app/test_videos/test.mp4
      -o /app/output/result.mp4
      -m /app/runs/detect/train/weights/best.pt
```

```bash
docker compose up
```

### Install from .whl

```bash
pip install dist/license_plate_detection-0.1.0-py3-none-any.whl

lpd video -i input.mp4 -o output.mp4 -m best.pt
```